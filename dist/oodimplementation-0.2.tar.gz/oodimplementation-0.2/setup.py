from setuptools import setup,find_packages
import pathlib

setup(
    name='oodimplementation',
    version='0.2',
    packages=find_packages(),
    description='This is a Test Package Published By Harrison'
)
      